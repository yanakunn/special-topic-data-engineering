<?php
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
?>
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-plug"></i>
        </div>
        <div class="sidebar-brand-text mx-3">STATICIP</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Data Table
    </div>

    <li class="nav-item">
        <a class="nav-link" href="activity.php">
            <i class="fas fa-atom"></i>
            <span>Activity</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="product.php">
            <i class="fas fa-database"></i>
            <span>Product</span></a>
    </li>

    <?php if($_SESSION['role'] == 1): ?>
    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item">
        <a class="nav-link" href="month.php">
            <i class="fas fa-fw fa-chart-line"></i>
            <span>Monthly</span></a>
    </li>
    
    <!-- Nav Item - Utilities Collapse Menu -->
    <li class="nav-item">
        <a class="nav-link" href="year.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Yearly</span></a>
    </li>

    <?php endif; ?>

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Logout -->
    <li class="nav-item">
        <a class="nav-link" href="./logout.php">
            <i class="fas fa-sign-out-alt fa-fw"></i>
            <span>Logout</span></a>
    </li>

</ul>