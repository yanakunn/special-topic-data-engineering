<?php 

//set DB Parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dashboard";

//Create connection
$con = mysqli_connect($servername, $username, $password, $dbname);

?>