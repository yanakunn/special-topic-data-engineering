<?php 
include("../../header.php");
//include("modals.php");

?>

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->  
      <section class="content-header">
      
      <div class="callout callout-info">
        <h4>Welcome
        


             <i>   <?php echo $_SESSION['firstname']." ". $_SESSION['lastname'] ?> ! </h4>
      </div>

 




    <!--    <small>Blank example to the fixed layout</small> -->


    <!-- Main content -->

            

            



      <div class="row">
      <div class="col-md-4">
<div class="box box-warning">
                      <div class="box-header with-border">
            

      <div class="row">
        <div class="col-md-12">
<div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">VISIION & MISSION STATEMENT</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                </button>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
 <center>            MISSION <BR>
Fellowship Baptist College commits to provide a Christ-centered learning environment conducive to the total development and competence of a person for service to humanity, for God's greatest glory.<BR>

VISION <BR>
A globally-recognized and responsive institution of learning, shaping lives by providing excellent Christian education.

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>







<!-- /body -->

        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
  </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>






<?php include("../../footer.php"); ?>