<?php 
include("../../../../connections/db-connect.php");


header("location: ../index.php")
?>