<?php
include("../connections/db-connect.php");
session_destroy();
header("location: ../../../../");
?>