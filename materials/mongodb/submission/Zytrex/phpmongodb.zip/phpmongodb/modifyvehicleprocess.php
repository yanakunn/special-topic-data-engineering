<?php
include("dbconnect.php");

if(isset($_POST['submit'])){
$vreg = $_POST['vreg'];
$vtype = $_POST['vtype'];
$vmodel = $_POST['vmodel'];
$vyear = $_POST['vyear'];
$vprice = $_POST['vprice'];
$image = $_FILES['ffilename'];
$vrating = $_POST['vrating'];
	echo "<br>";
	print_r($image);

	$imagefilename=$image['name'];
	print_r($imagefilename);
	echo "<br>";
	$imagefileerror=$image['error'];
	print_r($imagefileerror);
	echo "<br>";
	$imagefiletemp=$image['tmp_name'];
	print_r($imagefiletemp);
	echo "<br>";


	$filename_separate=explode('.', $imagefilename);
	print_r($filename_separate);
	echo "<br>";
	//$file_extension=strtolower($filename_separate[1]);
	//print_r($file_extension);
	$file_extension=strtolower(end($filename_separate));
	print_r($file_extension);
	echo "<br>";

	$extension=array('jpeg', 'jpg', 'png', 'jfif');
	if(in_array($file_extension, $extension)){
		$upload_image='image/'.$imagefilename;
		move_uploaded_file($imagefiletemp, $upload_image);
		$sql="UPDATE tb_car
			  SET c_reg = '$vreg', c_type = '$vtype', c_model = '$vmodel', c_year = '$vyear', c_price = '$vprice', c_filename = '$imagefilename', c_rating = '$vrating'
			  WHERE c_reg = '$vreg'";
		$result=mysqli_query($con,$sql);
		$tb_car = $db_car->tb_car;
		$filter = ['c_reg' => $vreg];
		$update = ['$set' => ['c_reg' => $vreg, 'c_type' => $vtype, 'c_model' => $vmodel, 'c_year' => $vyear, 'c_price' => $vprice, 'c_filename' => $imagefilename, 'c_rating' => $vrating]];
		$tb_car->updateOne($filter, $update);
		if($result){
			echo "Data inserted successfully";
		}else{
			die(mysqli_error($con));
		}
	}
}
header('location:vehicle.php');
?>


<div class="container">
	<h3>registration successfull. Please login to book</h3>
	<a href="login.php">Login Page</a>
</div>


<?php include 'footermain.php';?>