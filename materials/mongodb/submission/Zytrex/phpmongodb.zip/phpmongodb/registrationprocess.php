<?php 
include("dbconnect.php");
include("headermain.php");

?>

<head>
  <style>
    body{
      background-color: lightblue;
    }

    .form-popup {
      display: none;
      position: fixed;
      bottom: 0;
      right: 15px;
      border: 3px solid #f1f1f1;
      z-index: 9;
    }
  </style>
</head>

<?php

$fic = $_POST['fic'];
$fpwd = password_hash($_POST['fpwd'], PASSWORD_DEFAULT);
$fname = $_POST['fname'];
$fadd = $_POST['fadd'];
$fcontact = $_POST['fcontact'];
$flno = $_POST['flno'];

$sql = "INSERT INTO tb_user (u_id, u_pwd, u_name, u_address, u_phone, u_license, u_type) 
		VALUES ('$fic','$fpwd','$fname ','$fadd','$fcontact','$flno','2')";


mysqli_query($con, $sql);
mysqli_close($con);


?>



<body>

          <div class="modal" style="display: flex; justify-content: center; align-items: center;">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Confirmation</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true"></span>
                  </button>
                </div>
                <div class="modal-body">
                  <p>You have successfully registered.</p>
                </div>
                <div class="modal-footer">

                  <a href="login.php" class="btn btn-primary">Ok</a>
                </div>
              </div>
            </div>
          </div>
        </div>
    </body>

