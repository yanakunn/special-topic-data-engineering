<?php 
include('dbconnect.php');
include 'headermain.php'; ?>

<head>
  <style>
    .form-popup {
      display: none;
      position: fixed;
      bottom: 0;
      right: 15px;
      border: 3px solid #f1f1f1;
      z-index: 9;
    }
  </style>
</head>

<form method="POST" action="vehicleregistrationprocess.php" enctype="multipart/form-data">

<div class="container">
	
<form>
  <fieldset>
  	<br>
    <legend>Vehicle Registration Form</legend>

    <div class="form-group">
      <label for="exampleInputEmail1" class="form-label mt-4">Vehicle Registration Number</label>
      <input type="text" name="vreg" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter vehicle registration number" required>
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1" class="form-label mt-4">Vehicle Type</label>
      <input type="text" name="vtype" class="form-control" id="exampleInputPassword1" placeholder="Enter vehicle type" required>
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1" class="form-label mt-4">Vehicle Model</label>
      <input type="text" name="vmodel" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter vehicle model" required>
    </div>
    <div class="form-group">
      <label for="exampleTextarea" class="form-label mt-4">Year</label>
      <input type="text" name="vyear" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter vehicle year" required>
    </div>
    <div class="form-group">
      <label for="exampleInputContactNo" class="form-label mt-4">Vehicle Price</label>
      <input type="text" name="vprice" class="form-control" id="exampleInputContactNo" aria-describedby="emailHelp" placeholder="Enter vehicle rent price" required>
    </div>
    <div class="form-group">
      <label for="formFile" class="form-label mt-4">Choose File</label>
      <input class="form-control" type="file" name="ffilename" id="formFile">
    </div>
    <div class="form-group">
      <label for="exampleInputRatingNo" class="form-label mt-4">Vehicle Rating (0-10)</label>
      <input type="number" name="vrating" class="form-control" id="exampleInputRatingNo" aria-describedby="emailHelp" placeholder="Enter vehicle rating" required>
    </div>
    <br>
    <button type="reset" class="btn btn-primary">Clear Form</button>
    <button type="button" class="btn btn-outline-warning" onclick="myFunction1()">Add Vehicle</button>
  <div class="form-popup" id="myForm1">
    <div class="modal" style="display: flex; justify-content: center; align-items: center;">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Confirmation</h5>
            <button type="button" class="btn-close" onclick="closeForm()" data-bs-dismiss="modal" aria-label="Close">
              <span aria-hidden="true"></span>
            </button>
          </div>
          <div class="modal-body">
            <p>Are you sure want to add vehicle?</p>
          </div>
          <div class="modal-footer">
            <button type="submit" name="submit" class="btn btn-primary">Sure</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="closeForm()">Close</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  </fieldset>
</form>
<br><br>
</div>

<script>

function myFunction1(){
  document.getElementById("myForm1").style.display = "block";
}

function closeForm(){
  document.getElementById("myForm1").style.display = "none";
}
</script>

<?php include 'footermain.php'; ?>