<div class="footer">
  <p>Welcome to Zytrex!</p>
</div>
