<?php
$fic = $_SESSION['uid'];
$sql = "SELECT * FROM tb_user WHERE u_id = '$fic'";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_array($result);

 if($row['u_type']==2)  //cant jump to cust
   {
     session_destroy();
      echo "<script>
      window.location.href='login.php';
      alert('Sorry, you cannot jump to other page');
      </script>";
   }

?>



<!DOCTYPE html>
<html lang="en">
<head>
  <title>Carbook</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/x-icon" href="images/car.png">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <script type="text/javascript" src="js/main.js"></script>
<style>
.form-popup {
      display: none;
      position: fixed;
      bottom: 0;
      right: 15px;
      border: 3px solid #f1f1f1;
      z-index: 9;
    }

.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #7b8ab8;
   color: white;
   text-align: center;
}
</style>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-dark" id="ftco-navbar">
      <div class="container-fluid">
        <a class="navbar-brand" href="index.html">Car<span>Book</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active"><a href="staff.php" class="nav-link">Home</a></li>
            <li class="nav-item">
              <a class="nav-link" href="staffview.php">Booking List</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="vehicle.php">Vehicle</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#" onclick="myFunction2()">Logout</a>
              <div class="form-popup" id="myForm2">
                <div class="modal" style="display: flex; justify-content: center; align-items: center;">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Logout</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" onclick="closeForm2()" aria-label="Close">
                          <span aria-hidden="true"></span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <p>Are you sure want to logout?</p>
                      </div>
                      <div class="modal-footer">
                        <a href="logout.php" class="btn btn-primary px-4">Logout</a>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="closeForm2()">Close</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </nav>
<script>
  function myFunction2(){
    document.getElementById("myForm2").style.display = "block";
  }

  function closeForm2(){
    document.getElementById("myForm2").style.display = "none";
  }
</script>