<?php 
require 'vendor/autoload.php';
//Set Db parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_car";
//Create DB Connection
$con = mysqli_connect($servername, $username, $password, $dbname);
//Check DB Connection

$client = new MongoDB\Client;
$db_car = $client->db_car;

?>