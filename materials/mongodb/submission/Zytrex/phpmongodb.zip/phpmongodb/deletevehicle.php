<?php 
include('dbconnect.php');

//get booking ID from URL
if(isset($_GET['id']))
{
	$vid = $_GET['id'];
}

//SQL DELETE

$sql = "DELETE FROM tb_car WHERE c_reg='$vid'";
$result = mysqli_query($con, $sql);
mysqli_close($con);
$tb_car = $db_car->tb_car;
$filter = ['c_reg' => $vid];
$tb_car->deleteOne($filter);
header('location:vehicle.php');
?>