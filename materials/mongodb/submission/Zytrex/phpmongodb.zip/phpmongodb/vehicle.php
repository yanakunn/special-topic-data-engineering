<?php 
include ('dbconnect.php');

include 'headermain.php'; 


//Retrieve individual bookings
$sql = "SELECT * FROM tb_car ORDER BY c_rating DESC LIMIT 3";
$result = mysqli_query($con,$sql);
$sql2 = "SELECT * FROM tb_car";
$result2 = mysqli_query($con,$sql2);
?>

<div class="container">
	<br><h3><span class="flaticon-car mr-2"></span>Recommended Car</h3>
	<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">Vehicle</th>
      <th scope="col">Plate Number</th>
      <th scope="col">Type</th>
      <th scope="col">Model</th>
      <th scope="col">Year</th>
      <th scope="col">Price</th>
      <th scope="col">Rating</th>
      <th scope="col" class="text-center">Operation</th>
    </tr>
  </thead>
  <tbody>
  	<?php
  		while($row=mysqli_fetch_array($result))
  		{
  			echo '<tr class="table-warning">';
        echo '<td><img class="img-thumbnail" src="image/'.$row['c_filename'].'" alt="HTML5 Icon" style="width:128px;height:100%;"></td>';
  			echo "<td>".$row['c_reg']."</td>";
        echo "<td>".$row['c_type']."</td>";
  			echo "<td>".$row['c_model']."</td>";
  			echo "<td>".$row['c_year']."</td>";
  			echo "<td>RM".$row['c_price']."</td>";
        echo "<td>".$row['c_rating']."/10</td>";
  			echo "<td class='text-center'>";
  				echo "<a href='modifyvehicle.php?id=".$row['c_reg']."'class='btn btn-outline-warning'>Modify</a> &nbsp";
          echo "<a href='deletevehicle.php?id=".$row['c_reg']."'class='btn btn-outline-warning'>Delete</a>";
  			echo "</td>";
  			echo '</tr>';

  		}
  	?>
  </tbody>
</table>

<br><h3><span class="flaticon-rent mr-2"></span>Vehicle List</h3>
	<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">Vehicle</th>
      <th scope="col">Plate Number</th>
      <th scope="col">Type</th>
      <th scope="col">Model</th>
      <th scope="col">Year</th>
      <th scope="col">Price</th>
      <th scope="col">Rating</th>
      <th scope="col" class="text-center">Operation</th>
    </tr>
  </thead>
  <tbody>
  	<?php
  		while($row=mysqli_fetch_array($result2))
  		{
  			echo '<tr class="table-warning">';
        echo '<td><img class="img-thumbnail" src="image/'.$row['c_filename'].'" alt="HTML5 Icon" style="width:128px;height:100%;"></td>';
  			echo "<td>".$row['c_reg']."</td>";
        echo "<td>".$row['c_type']."</td>";
  			echo "<td>".$row['c_model']."</td>";
  			echo "<td>".$row['c_year']."</td>";
  			echo "<td>RM".$row['c_price']."</td>";
        echo "<td>".$row['c_rating']."/10</td>";
  			echo "<td class='text-center'>";
  				echo "<a href='modifyvehicle.php?id=".$row['c_reg']."'class='btn btn-outline-warning'>Modify</a> &nbsp";
          echo "<a href='deletevehicle.php?id=".$row['c_reg']."'class='btn btn-outline-warning'>Delete</a>";
  			echo "</td>";
  			echo '</tr>';

  		}
  	?>
  </tbody>
</table>
<a href="registervehicle.php"class="btn btn-outline-warning">Add Vehicle</a>
<a href="index.php" class="btn btn-primary">Back</a>
</div>
<br><br>